exports.acceptAmount = amount => amount > 0;












exports.label = 'User renamed ledger';
