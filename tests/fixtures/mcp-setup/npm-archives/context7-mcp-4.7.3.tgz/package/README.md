![Cover](https://github.com/upstash/context7/blob/master/public/cover.png?raw=true)

[![Install MCP Server](https://cursor.com/deeplink/mcp-install-dark.svg)](https://cursor.com/en/install-mcp?name=context7&config=eyJ1cmwiOiJodHRwczovL21jcC5jb250ZXh0Ny5jb20vbWNwIn0%3D) [<img alt="Install in VS Code (npx)" src="https://img.shields.io/badge/Install%20in%20VS%20Code-0098FF?style=for-the-badge&logo=visualstudiocode&logoColor=white">](https://insiders.vscode.dev/redirect?url=vscode%3Amcp%2Finstall%3F%7B%22name%22%3A%22context7%22%2C%22command%22%3A%22npx%22%2C%22args%22%3A%5B%22-y%22%2C%22%40upstash%2Fcontext7-mcp%40latest%22%5D%7D)

# Context7 MCP - Up-to-date Docs for AI Agents

[![Website](https://img.shields.io/badge/Website-context7.com-blue)](https://context7.com) [![NPM Version](https://img.shields.io/npm/v/%40upstash%2Fcontext7-mcp?color=red)](https://www.npmjs.com/package/@upstash/context7-mcp) [![MIT licensed](https://img.shields.io/npm/l/%40upstash%2Fcontext7-mcp)](./LICENSE)

[![繁體中文](https://img.shields.io/badge/docs-繁體中文-yellow)](./i18n/README.zh-TW.md) [![简体中文](https://img.shields.io/badge/docs-简体中文-yellow)](./i18n/README.zh-CN.md) [![日本語](https://img.shields.io/badge/docs-日本語-b7003a)](./i18n/README.ja.md) [![한국어 문서](https://img.shields.io/badge/docs-한국어-green)](./i18n/README.ko.md) [![Documentación en Español](https://img.shields.io/badge/docs-Español-orange)](./i18n/README.es.md) [![Documentation en Français](https://img.shields.io/badge/docs-Français-blue)](./i18n/README.fr.md) [![Documentação em Português (Brasil)](<https://img.shields.io/badge/docs-Português%20(Brasil)-purple>)](./i18n/README.pt-BR.md) [![Documentazione in italiano](https://img.shields.io/badge/docs-Italian-red)](./i18n/README.it.md) [![Dokumentasi Bahasa Indonesia](https://img.shields.io/badge/docs-Bahasa%20Indonesia-pink)](./i18n/README.id-ID.md) [![Dokumentation auf Deutsch](https://img.shields.io/badge/docs-Deutsch-darkgreen)](./i18n/README.de.md) [![Документация на русском языке](https://img.shields.io/badge/docs-Русский-darkblue)](./i18n/README.ru.md) [![Українська документація](https://img.shields.io/badge/docs-Українська-lightblue)](./i18n/README.uk.md) [![Türkçe Doküman](https://img.shields.io/badge/docs-Türkçe-blue)](./i18n/README.tr.md) [![Arabic Documentation](https://img.shields.io/badge/docs-Arabic-white)](./i18n/README.ar.md) [![Tiếng Việt](https://img.shields.io/badge/docs-Tiếng%20Việt-red)](./i18n/README.vi.md)

## ❌ Without Context7

LLMs rely on outdated or generic information about the libraries you use. You get:

- ❌ Code examples are outdated and based on year-old training data
- ❌ Hallucinated APIs that don't even exist
- ❌ Generic answers for old package versions

## ✅ With Context7

Context7 MCP pulls up-to-date, version-specific documentation and code examples straight from the source — and gives them to your coding agent.

Add `use context7` to your prompt (or [set up a rule](#️-installation) to auto-invoke):

```txt
Create a Next.js proxy that checks for a valid JWT in cookies
and redirects unauthenticated users to `/login`. use context7
```

```txt
Configure a Cloudflare Worker script to cache
JSON API responses for five minutes. use context7
```

Context7 fetches up-to-date code examples and documentation right into your coding agent's context.

- 1️⃣ Write your prompt naturally
- 2️⃣ Tell the LLM to `use context7` (or [set up a rule](#️-installation) once)
- 3️⃣ Get working code answers

No tab-switching, no hallucinated APIs that don't exist, no outdated code generation.

> [!NOTE]
> This repository hosts the source code of Context7 MCP server. The supporting components — API backend, parsing engine, and crawling engine — are private and not part of this release.

## 📚 Adding Projects

Check out our [project addition guide](https://context7.com/docs/adding-libraries) to learn how to add (or update) your favorite libraries to Context7.

## 🛠️ Installation

### Requirements

- Node.js >= v20.18.1
- Cursor, Claude Code, VSCode, Devin Desktop or another MCP Client
- Context7 API Key (Optional) for higher rate limits and private repositories (Get yours by creating an account at [context7.com/dashboard](https://context7.com/dashboard?tab=settings))

> [!TIP]
> **Recommended Post-Setup: Add a Rule to Auto-Invoke Context7**
>
> After installing Context7 (see instructions below), enhance your workflow by adding a rule so you don't have to type `use context7` in every prompt. Define a simple rule in your MCP client's rule section to automatically invoke Context7 on any code question:
>
> - For Devin Desktop, in `.devin/rules/` directory
> - For Cursor, from `Cursor Settings > Rules` section
> - For Claude Code, in `CLAUDE.md` file
> - Or the equivalent in your MCP client
>
> **Example Rule:**
>
> ```txt
> Always use context7 when I need code generation, setup or configuration steps, or
> library/API documentation. This means you should automatically use the Context7 MCP
> tools to resolve library id and get library docs without me having to explicitly ask.
> ```
>
> From then on, you'll get Context7's docs in any related conversation without typing anything extra. You can alter the rule to match your use cases.

<details>
<summary><b>Installing via Smithery</b></summary>

To install Context7 MCP Server for any client automatically via [Smithery](https://smithery.ai/server/@upstash/context7-mcp):

```bash
npx -y @smithery/cli@latest install @upstash/context7-mcp --client <CLIENT_NAME> --key <YOUR_SMITHERY_KEY>
```

You can find your Smithery key in the [Smithery.ai webpage](https://smithery.ai/server/@upstash/context7-mcp).

</details>

<details>
<summary><b>Install in Cursor</b></summary>

Go to: `Settings` -> `Cursor Settings` -> `MCP` -> `Add new global MCP server`

Pasting the following configuration into your Cursor `~/.cursor/mcp.json` file is the recommended approach. You may also install in a specific project by creating `.cursor/mcp.json` in your project folder. See [Cursor MCP docs](https://docs.cursor.com/context/model-context-protocol) for more info.

> Since Cursor 1.0, you can click the install button below for instant one-click installation.

#### Cursor Remote Server Connection

[![Install MCP Server](https://cursor.com/deeplink/mcp-install-dark.svg)](https://cursor.com/en/install-mcp?name=context7&config=eyJ1cmwiOiJodHRwczovL21jcC5jb250ZXh0Ny5jb20vbWNwIn0%3D)

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

#### Cursor Local Server Connection

[![Install MCP Server](https://cursor.com/deeplink/mcp-install-dark.svg)](https://cursor.com/en/install-mcp?name=context7&config=eyJjb21tYW5kIjoibnB4IC15IEB1cHN0YXNoL2NvbnRleHQ3LW1jcCJ9)

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Install in Claude Code</b></summary>

Run this command. See [Claude Code MCP docs](https://docs.anthropic.com/en/docs/claude-code/mcp) for more info.

#### Claude Code Local Server Connection

```sh
claude mcp add --scope user context7 -- npx -y @upstash/context7-mcp --api-key YOUR_API_KEY
```

#### Claude Code Remote Server Connection

```sh
claude mcp add --scope user --header "Authorization: Bearer YOUR_API_KEY" --transport http context7 https://mcp.context7.com/mcp
```

> Remove `--scope user` to install for the current project only.

</details>

<details>
<summary><b>Install in Amp</b></summary>

Run this command in your terminal. See [Amp MCP docs](https://ampcode.com/manual#mcp) for more info.

#### With OAuth

```sh
amp mcp add context7 https://mcp.context7.com/mcp/oauth
```

#### With API Key (Higher Rate Limits & Private Repos)

```sh
amp mcp add context7 --header "Authorization=Bearer YOUR_API_KEY" https://mcp.context7.com/mcp
```

</details>

<details>
<summary><b>Install in Devin Desktop</b></summary>

Add this to your Devin Desktop MCP config file. See [Devin Desktop MCP docs](https://docs.devin.ai/desktop/cascade/mcp) for more info.

#### Devin Desktop Remote Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "serverUrl": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

#### Devin Desktop Local Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Install in VS Code</b></summary>

[<img alt="Install in VS Code (npx)" src="https://img.shields.io/badge/VS_Code-VS_Code?style=flat-square&label=Install%20Context7%20MCP&color=0098FF">](https://insiders.vscode.dev/redirect?url=vscode%3Amcp%2Finstall%3F%7B%22name%22%3A%22context7%22%2C%22command%22%3A%22npx%22%2C%22args%22%3A%5B%22-y%22%2C%22%40upstash%2Fcontext7-mcp%40latest%22%5D%7D)
[<img alt="Install in VS Code Insiders (npx)" src="https://img.shields.io/badge/VS_Code_Insiders-VS_Code_Insiders?style=flat-square&label=Install%20Context7%20MCP&color=24bfa5">](https://insiders.vscode.dev/redirect?url=vscode-insiders%3Amcp%2Finstall%3F%7B%22name%22%3A%22context7%22%2C%22command%22%3A%22npx%22%2C%22args%22%3A%5B%22-y%22%2C%22%40upstash%2Fcontext7-mcp%40latest%22%5D%7D)

Add this to your VS Code MCP config file. See [VS Code MCP docs](https://code.visualstudio.com/docs/copilot/chat/mcp-servers) for more info.

#### VS Code Remote Server Connection

```json
"mcp": {
  "servers": {
    "context7": {
      "type": "http",
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

#### VS Code Local Server Connection

```json
"mcp": {
  "servers": {
    "context7": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary>
<b>Install in Cline</b>
</summary>

You can easily install Context7 through the [Cline MCP Server Marketplace](https://cline.bot/mcp-marketplace) by following these instructions:

1. Open **Cline**.
2. Click the hamburger menu icon (☰) to enter the **MCP Servers** section.
3. Use the search bar within the **Marketplace** tab to find _Context7_.
4. Click the **Install** button.

Or you can directly edit MCP servers configuration:

1. Open **Cline**.
2. Click the hamburger menu icon (☰) to enter the **MCP Servers** section.
3. Choose **Remote Servers** tab.
4. Click the **Edit Configuration** button.
5. Add context7 to `mcpServers`:

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp",
      "type": "streamableHttp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

</details>

<details>
<summary><b>Install in Zed</b></summary>

It can be installed via [Zed Extensions](https://zed.dev/extensions?query=Context7) or you can add this to your Zed `settings.json`. See [Zed Context Server docs](https://zed.dev/docs/assistant/context-servers) for more info.

```json
{
  "context_servers": {
    "Context7": {
      "source": "custom",
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Install in Augment Code</b></summary>

To configure Context7 MCP in Augment Code, you can use either the graphical interface or manual configuration.

### **A. Using the Augment Code UI**

1. Click the hamburger menu.
2. Select **Settings**.
3. Navigate to the **Tools** section.
4. Click the **+ Add MCP** button.
5. Enter the following command:

   ```
   npx -y @upstash/context7-mcp@latest
   ```

6. Name the MCP: **Context7**.
7. Click the **Add** button.

Once the MCP server is added, you can start using Context7's up-to-date code documentation features directly within Augment Code.

---

### **B. Manual Configuration**

1. Press Cmd/Ctrl Shift P or go to the hamburger menu in the Augment panel
2. Select Edit Settings
3. Under Advanced, click Edit in settings.json
4. Add the server configuration to the `mcpServers` array in the `augment.advanced` object

```json
"augment.advanced": {
  "mcpServers": [
    {
      "name": "context7",
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  ]
}
```

Once the MCP server is added, restart your editor. If you receive any errors, check the syntax to make sure closing brackets or commas are not missing.

</details>

<details>
<summary><b>Install in Kilo Code</b></summary>

You can configure the Context7 MCP server in **Kilo Code** using either the UI or by editing your project's MCP configuration file.

Kilo Code supports two configuration levels:

- **Global MCP Configuration** — stored in `mcp_settings.json`
- **Project-level MCP Configuration** — stored in `.kilocode/mcp.json` (recommended)

If a server is defined in both places, the **project-level configuration overrides the global one**.

---

## Configure via Kilo Code UI

1. Open **Kilo Code**.
2. Click the **Settings** icon in the top-right corner.
3. Navigate to **Settings → MCP Servers**.
4. Click **Add Server**.
5. Choose **HTTP Server** (Streamable HTTP Transport).
6. Enter the details:

**URL**
`https://mcp.context7.com/mcp`

**Headers → Add Header**

- **Key:** `Authorization`
- **Value:** `Bearer YOUR_API_KEY`

7. Click **Save**.
8. Ensure the server toggle is **enabled**.
9. If needed, click **Refresh MCP Servers** to reload the configuration.

---

## Manual Configuration (`.kilocode/mcp.json`)

To configure the server at the project level (recommended for team environments), create the following file:

**`.kilocode/mcp.json`:**

```json
{
  "mcpServers": {
    "context7": {
      "type": "streamable-http",
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      },
      "alwaysAllow": [],
      "disabled": false
    }
  }
}
```

Replace YOUR_API_KEY with your actual Context7 API key.

After saving the file:

- Open Settings → MCP Servers

- Click Refresh MCP Servers

Kilo Code will automatically detect and load the configuration.

</details>

<details>
<summary><b>Install in Google Antigravity</b></summary>

Add this to your Antigravity MCP config file. See [Antigravity MCP docs](https://antigravity.google/docs/mcp) for more info.

#### Google Antigravity Remote Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "serverUrl": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

#### Google Antigravity Local Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Install in Roo Code</b></summary>

Add this to your Roo Code MCP configuration file. See [Roo Code MCP docs](https://docs.roocode.com/features/mcp/using-mcp-in-roo) for more info.

#### Roo Code Remote Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "type": "streamable-http",
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

#### Roo Code Local Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Install in Gemini CLI</b></summary>

See [Gemini CLI Configuration](https://google-gemini.github.io/gemini-cli/docs/tools/mcp-server.html) for details.

1.  Open the Gemini CLI settings file. The location is `~/.gemini/settings.json` (where `~` is your home directory).
2.  Add the following to the `mcpServers` object in your `settings.json` file:

```json
{
  "mcpServers": {
    "context7": {
      "httpUrl": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY",
        "Accept": "application/json, text/event-stream"
      }
    }
  }
}
```

Or, for a local server:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

If the `mcpServers` object does not exist, create it.

</details>

<details>
<summary><b>Install in Qwen Coder</b></summary>

See [Qwen Coder MCP Configuration](https://qwenlm.github.io/qwen-code-docs/en/developers/tools/mcp-server/#how-to-set-up-your-mcp-server) for details.

1.  Open the Qwen Coder settings file. The location is `~/.qwen/settings.json` (where `~` is your home directory).
2.  Add the following to the `mcpServers` object in your `settings.json` file:

```json
{
  "mcpServers": {
    "context7": {
      "httpUrl": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY",
        "Accept": "application/json, text/event-stream"
      }
    }
  }
}
```

Or, for a local server:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

If the `mcpServers` object does not exist, create it.

</details>

<details>
<summary><b>Install in Claude Desktop</b></summary>

#### Remote Server Connection

Open Claude Desktop and navigate to Settings > Connectors > Add Custom Connector. Enter the name as `Context7` and the remote MCP server URL as `https://mcp.context7.com/mcp`.

#### Local Server Connection

Open Claude Desktop developer settings and edit your `claude_desktop_config.json` file to add the following configuration. See [Claude Desktop MCP docs](https://modelcontextprotocol.io/quickstart/user) for more info.

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Install in OpenCode</b></summary>

Add this to your `opencode.json` file. The shape depends on your OpenCode version. Run `opencode --version` to check it.

- **OpenCode 2.x** keeps servers in `mcp.servers` and connects to each one unless you set `"disabled": true`. It also accepts the 1.x shape. See the [OpenCode 2.x MCP docs](https://opencode.ai/v2/docs/mcp-servers).
- **OpenCode 1.x** reads servers directly from `mcp` and uses `"enabled": true`. It rejects a config that contains `mcp.servers`. See the [OpenCode 1.x MCP docs](https://opencode.ai/docs/mcp-servers).

#### OpenCode 2.x Remote Server Connection

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "servers": {
      "context7": {
        "type": "remote",
        "url": "https://mcp.context7.com/mcp",
        "headers": {
          "Authorization": "Bearer YOUR_API_KEY"
        }
      }
    }
  }
}
```

#### OpenCode 1.x Remote Server Connection

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "context7": {
      "type": "remote",
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      },
      "enabled": true
    }
  }
}
```

#### OpenCode 2.x Local Server Connection

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "servers": {
      "context7": {
        "type": "local",
        "command": ["npx", "-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
      }
    }
  }
}
```

#### OpenCode 1.x Local Server Connection

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "context7": {
      "type": "local",
      "command": ["npx", "-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"],
      "enabled": true
    }
  }
}
```

</details>

<details>
<summary><b>Install in OpenAI Codex</b></summary>

See [OpenAI Codex](https://github.com/openai/codex) for more information.

Add the following configuration to your OpenAI Codex MCP server settings:

#### Local Server Connection

```toml
[mcp_servers.context7]
args = ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
command = "npx"
startup_timeout_sec = 20
```

#### Remote Server Connection

```toml
[mcp_servers.context7]
url = "https://mcp.context7.com/mcp"
http_headers = { "Authorization" = "Bearer YOUR_API_KEY" }
```

> Optional troubleshooting — only if you see startup "request timed out" or "not found program". Most users can ignore this.
>
> - First try: increase `startup_timeout_sec` to `40` and retry.
> - Windows quick fix (absolute `npx` path + explicit env):
>
> ```toml
> [mcp_servers.context7]
> command = "C:\\Users\\yourname\\AppData\\Roaming\\npm\\npx.cmd"
> args = [
>   "-y",
>   "@upstash/context7-mcp",
>   "--api-key",
>   "YOUR_API_KEY"
> ]
> env = { SystemRoot="C:\\Windows", APPDATA="C:\\Users\\yourname\\AppData\\Roaming" }
> startup_timeout_sec = 40
> ```
>
> - macOS quick fix (use Node + installed package entry point):
>
> ```toml
> [mcp_servers.context7]
> command = "/Users/yourname/.nvm/versions/node/v22.14.0/bin/node"
> args = ["/Users/yourname/.nvm/versions/node/v22.14.0/lib/node_modules/@upstash/context7-mcp/dist/index.js",
>   "--transport",
>   "stdio",
>   "--api-key",
>   "YOUR_API_KEY"
> ]
> ```
>
> Notes: Replace `yourname` with your OS username. Explicitly setting `APPDATA` and `SystemRoot` is essential because these are required by `npx` on Windows but not set by certain versions of OpenAI Codex mcp clients by default.

</details>

<details>

<summary><b>Install in JetBrains AI Assistant</b></summary>

See [JetBrains AI Assistant Documentation](https://www.jetbrains.com/help/ai-assistant/configure-an-mcp-server.html) for more details.

1. In JetBrains IDEs, go to `Settings` -> `Tools` -> `AI Assistant` -> `Model Context Protocol (MCP)`
2. Click `+ Add`.
3. Click on `Command` in the top-left corner of the dialog and select the As JSON option from the list
4. Add this configuration and click `OK`

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

5. Click `Apply` to save changes.
6. The same way context7 could be added for JetBrains Junie in `Settings` -> `Tools` -> `Junie` -> `MCP Settings`

</details>

<details>

<summary><b>Install in Kiro</b></summary>

See [Kiro Model Context Protocol Documentation](https://kiro.dev/docs/mcp/configuration/) for details.

[![Add to Kiro](https://kiro.dev/images/add-to-kiro.svg)](https://kiro.dev/launch/mcp/add?name=context7&config=%7B%22url%22%3A%22https%3A%2F%2Fmcp.context7.com%2Fmcp%22%2C%22disabled%22%3Afalse%2C%22autoApprove%22%3A%5B%5D%7D)

1. Navigate `Kiro` > `MCP Servers`
2. Add a new MCP server by clicking the `+ Add` button.
3. Paste one of the configurations below:

#### Kiro Remote Server Connection

```json
{
  "mcpServers": {
    "Context7": {
      "url": "https://mcp.context7.com/mcp"
    }
  }
}
```

To use an API key in Kiro, add:

```json
"headers": {
  "Authorization": "Bearer YOUR_API_KEY"
}
```

You can create an API key at [context7.com/dashboard](https://context7.com/dashboard?tab=settings) for authenticated usage and higher rate limits.

#### Kiro Local Server Connection

```json
{
  "mcpServers": {
    "Context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"],
      "env": {},
      "disabled": false,
      "autoApprove": []
    }
  }
}
```

4. Click `Save` to apply the changes.

</details>

<details>
<summary><b>Install in Trae</b></summary>

Use the Add manually feature and fill in the JSON configuration information for that MCP server.
For more details, visit the [Trae documentation](https://docs.trae.ai/ide/model-context-protocol?_lang=en).

#### Trae Remote Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp"
    }
  }
}
```

#### Trae Local Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Using Bun or Deno</b></summary>

Use these alternatives to run the local Context7 MCP server with other runtimes. These examples work for any client that supports launching a local MCP server via command + args.

#### Bun

```json
{
  "mcpServers": {
    "context7": {
      "command": "bunx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

#### Deno

```json
{
  "mcpServers": {
    "context7": {
      "command": "deno",
      "args": [
        "run",
        "--allow-env=NO_DEPRECATION,TRACE_DEPRECATION",
        "--allow-net",
        "npm:@upstash/context7-mcp"
      ]
    }
  }
}
```

</details>

<details>
<summary><b>Using Docker</b></summary>

If you prefer to run the MCP server in a Docker container:

1. **Build the Docker Image:**

   First, create a `Dockerfile` in the project root (or anywhere you prefer):

   <details>
   <summary>Click to see Dockerfile content</summary>

   ```Dockerfile
   FROM node:20-alpine

   WORKDIR /app

   # Install the latest version globally
   RUN npm install -g @upstash/context7-mcp

   # Expose default port if needed (optional, depends on MCP client interaction)
   # EXPOSE 3000

   # Default command to run the server
   CMD ["context7-mcp", "--transport", "stdio"]
   ```

   </details>

   Then, build the image using a tag (e.g., `context7-mcp`). **Make sure Docker Desktop (or the Docker daemon) is running.** Run the following command in the same directory where you saved the `Dockerfile`:

   ```bash
   docker build -t context7-mcp .
   ```

2. **Configure Your MCP Client:**

   Update your MCP client's configuration to use the Docker command.

   _Example for a cline_mcp_settings.json:_

   ```json
   {
     "mcpServers": {
       "Сontext7": {
         "autoApprove": [],
         "disabled": false,
         "timeout": 60,
         "command": "docker",
         "args": ["run", "-i", "--rm", "context7-mcp"],
         "transportType": "stdio"
       }
     }
   }
   ```

   _Note: This is an example configuration. Please refer to the specific examples for your MCP client (like Cursor, VS Code, etc.) earlier in this README to adapt the structure (e.g., `mcpServers` vs `servers`). Also, ensure the image name in `args` matches the tag used during the `docker build` command._

   If you use the Docker MCP Toolkit image (`mcp/context7`) with a stdio-based client,
   set `MCP_TRANSPORT=stdio` so the container starts with stdio transport instead of its
   HTTP default. For Cline, Roo Code, and Claude Desktop, use:

   ```json
   {
     "mcpServers": {
       "context7": {
         "command": "docker",
         "args": ["run", "-i", "--rm", "-e", "MCP_TRANSPORT=stdio", "mcp/context7"]
       }
     }
   }
   ```

   For VS Code, use the same Docker command in the `servers` format:

   ```json
   {
     "servers": {
       "context7": {
         "type": "stdio",
         "command": "docker",
         "args": ["run", "-i", "--rm", "-e", "MCP_TRANSPORT=stdio", "mcp/context7"]
       }
     }
   }
   ```

   Keep using the remote server URL for HTTP-based clients.

</details>

<details>
<summary><b>Install Using the Desktop Extension</b></summary>

Install the [context7.mcpb](mcpb/context7.mcpb) file under the mcpb folder and add it to your client. For more information, please check out [MCP bundles docs](https://github.com/anthropics/mcpb#mcp-bundles-mcpb).

</details>

<details>
<summary><b>Install in Windows</b></summary>

The configuration on Windows is slightly different compared to Linux or macOS (_`Cline` is used in the example_). The same principle applies to other editors; refer to the configuration of `command` and `args`.

```json
{
  "mcpServers": {
    "github.com/upstash/context7-mcp": {
      "command": "cmd",
      "args": ["/c", "npx", "-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"],
      "disabled": false,
      "autoApprove": []
    }
  }
}
```

</details>

<details>
<summary><b>Install in Amazon Q Developer CLI</b></summary>

Add this to your Amazon Q Developer CLI configuration file. See [Amazon Q Developer CLI docs](https://docs.aws.amazon.com/amazonq/latest/qdeveloper-ug/command-line-mcp-configuration.html) for more details.

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Install in Warp</b></summary>

See [Warp Model Context Protocol Documentation](https://docs.warp.dev/knowledge-and-collaboration/mcp#adding-an-mcp-server) for details.

1. Navigate `Settings` > `AI` > `Manage MCP servers`.
2. Add a new MCP server by clicking the `+ Add` button.
3. Paste the configuration given below:

```json
{
  "Context7": {
    "command": "npx",
    "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"],
    "env": {},
    "working_directory": null,
    "start_on_launch": true
  }
}
```

4. Click `Save` to apply the changes.

</details>

<details>

<summary><b>Install in Copilot Coding Agent</b></summary>

## Using Context7 with Copilot Coding Agent

Add the following configuration to the `mcp` section of your Copilot Coding Agent configuration file Repository->Settings->Copilot->Coding agent->MCP configuration:

```json
{
  "mcpServers": {
    "context7": {
      "type": "http",
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      },
      "tools": ["query-docs", "resolve-library-id"]
    }
  }
}
```

For more information, see the [official GitHub documentation](https://docs.github.com/en/enterprise-cloud@latest/copilot/how-tos/agents/copilot-coding-agent/extending-copilot-coding-agent-with-mcp).

</details>

<details>
<summary><b>Install in Copilot CLI</b></summary>

1.  Open the Copilot CLI MCP config file. The location is `~/.copilot/mcp-config.json` (where `~` is your home directory).
2.  Add the following to the `mcpServers` object in your `mcp-config.json` file:

```json
{
  "mcpServers": {
    "context7": {
      "type": "http",
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      },
      "tools": ["query-docs", "resolve-library-id"]
    }
  }
}
```

Or, for a local server:

```json
{
  "mcpServers": {
    "context7": {
      "type": "local",
      "command": "npx",
      "tools": ["query-docs", "resolve-library-id"],
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

If the `mcp-config.json` file does not exist, create it.

</details>

<details>
<summary><b>Install in LM Studio</b></summary>

See [LM Studio MCP Support](https://lmstudio.ai/blog/lmstudio-v0.3.17) for more information.

#### One-click install:

[![Add MCP Server context7 to LM Studio](https://files.lmstudio.ai/deeplink/mcp-install-light.svg)](https://lmstudio.ai/install-mcp?name=context7&config=eyJjb21tYW5kIjoibnB4IiwiYXJncyI6WyIteSIsIkB1cHN0YXNoL2NvbnRleHQ3LW1jcCJdfQ%3D%3D)

#### Manual set-up:

1. Navigate to `Program` (right side) > `Install` > `Edit mcp.json`.
2. Paste the configuration given below:

```json
{
  "mcpServers": {
    "Context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

3. Click `Save` to apply the changes.
4. Toggle the MCP server on/off from the right hand side, under `Program`, or by clicking the plug icon at the bottom of the chat box.

</details>

<details>
<summary><b>Install in Visual Studio 2022</b></summary>

You can configure Context7 MCP in Visual Studio 2022 by following the [Visual Studio MCP Servers documentation](https://learn.microsoft.com/visualstudio/ide/mcp-servers?view=vs-2022).

Add this to your Visual Studio MCP config file (see the [Visual Studio docs](https://learn.microsoft.com/visualstudio/ide/mcp-servers?view=vs-2022) for details):

```json
{
  "inputs": [],
  "servers": {
    "context7": {
      "type": "http",
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

Or, for a local server:

```json
{
  "mcp": {
    "servers": {
      "context7": {
        "type": "stdio",
        "command": "npx",
        "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
      }
    }
  }
}
```

For more information and troubleshooting, refer to the [Visual Studio MCP Servers documentation](https://learn.microsoft.com/visualstudio/ide/mcp-servers?view=vs-2022).

</details>

<details>
<summary><b>Install in Crush</b></summary>

Add this to your Crush configuration file. See [Crush MCP docs](https://github.com/charmbracelet/crush#mcps) for more info.

#### Crush Remote Server Connection (HTTP)

```json
{
  "$schema": "https://charm.land/crush.json",
  "mcp": {
    "context7": {
      "type": "http",
      "url": "https://mcp.context7.com/mcp",
      "headers": {
        "Authorization": "Bearer YOUR_API_KEY"
      }
    }
  }
}
```

#### Crush Local Server Connection

```json
{
  "$schema": "https://charm.land/crush.json",
  "mcp": {
    "context7": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Install in BoltAI</b></summary>

Open the "Settings" page of the app, navigate to "Plugins," and enter the following JSON:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

Once saved, enter in the chat `query-docs` followed by your Context7 documentation ID (e.g., `query-docs /nuxt/ui how to set up a theme`). More information is available on [BoltAI's Documentation site](https://docs.boltai.com/docs/plugins/mcp-servers). For BoltAI on iOS, [see this guide](https://docs.boltai.com/docs/boltai-mobile/mcp-servers).

</details>

<details>
<summary><b>Install in Rovo Dev CLI</b></summary>

Edit your Rovo Dev CLI MCP config by running the command below -

```bash
acli rovodev mcp
```

Example config -

#### Remote Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp"
    }
  }
}
```

#### Local Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

<details>
<summary><b>Install in Zencoder</b></summary>

To configure Context7 MCP in Zencoder, follow these steps:

1. Go to the Zencoder menu (...)
2. From the dropdown menu, select Agent tools
3. Click on the Add custom MCP
4. Add the name and server configuration from below, and make sure to hit the Install button

```json
{
  "command": "npx",
  "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
}
```

Once the MCP server is added, you can easily continue using it.

</details>

<details>
<summary><b>Install in Qodo Gen</b></summary>

See [Qodo Gen docs](https://docs.qodo.ai/qodo-documentation/qodo-gen/qodo-gen-chat/agentic-mode/agentic-tools-mcps) for more details.

1. Open Qodo Gen chat panel in VSCode or IntelliJ.
2. Click Connect more tools.
3. Click + Add new MCP.
4. Add the following configuration:

#### Qodo Gen Local Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

#### Qodo Gen Remote Server Connection

```json
{
  "mcpServers": {
    "context7": {
      "url": "https://mcp.context7.com/mcp"
    }
  }
}
```

</details>

<details>
<summary><b>Install in Perplexity Desktop</b></summary>

See [Local and Remote MCPs for Perplexity](https://www.perplexity.ai/help-center/en/articles/11502712-local-and-remote-mcps-for-perplexity) for more information.

1. Navigate `Perplexity` > `Settings`
2. Select `Connectors`.
3. Click `Add Connector`.
4. Select `Advanced`.
5. Enter Server Name: `Context7`
6. Paste the following JSON in the text area:

```json
{
  "args": ["-y", "@upstash/context7-mcp", "--api-key", "YOUR_API_KEY"],
  "command": "npx",
  "env": {}
}
```

7. Click `Save`.

</details>

<details>
<summary><b>Install in Factory</b></summary>

Factory's droid supports MCP servers through its CLI. See [Factory MCP docs](https://docs.factory.ai/cli/configuration/mcp) for more info.

#### Factory Remote Server Connection (HTTP)

Run this command in your terminal:

```sh
droid mcp add context7 https://mcp.context7.com/mcp --type http --header "Authorization: Bearer YOUR_API_KEY"
```

#### Factory Local Server Connection (Stdio)

Run this command in your terminal:

```sh
droid mcp add context7 "npx -y @upstash/context7-mcp" --env CONTEXT7_API_KEY=YOUR_API_KEY
```

Once configured, Context7 tools will be available in your droid sessions. Type `/mcp` within droid to manage servers, authenticate, and view available tools.

</details>

<details>
<summary><b>Install in Emdash</b></summary>

[Emdash](https://github.com/generalaction/emdash) is an orchestration layer for running multiple coding agents in parallel. Provider-agnostic, worktree-isolated, and local-first. Emdash supports Context7 MCP to enable Context7 for your agents.

**What Emdash provides:**

- Global toggle: Settings → MCP → "Enable Context7 MCP"
- Per-workspace enable: The Context7 button in the ProviderBar (off by default). First click enables it for that workspace. Clicking again disables it.
- ProviderBar: The Context7 button shows status, a short explanation, and a link to docs

**What you still need to do:**
Configure your coding agent (Codex, Claude Code, Cursor, etc.) to connect to Context7 MCP. Emdash does not modify your agent's config. See the respective MCP configuration sections above for your agent (e.g., OpenAI Codex, Claude Code, Cursor).

See the [Emdash repository](https://github.com/generalaction/emdash) for more information.

</details>

<details>
<summary><b>Install in Autohand Code</b></summary>

Use the [Autohand Code CLI](https://github.com/autohandai/code-cli/) to add the local Context7 server:

```sh
autohand mcp add context7 npx -y @upstash/context7-mcp --api-key YOUR_API_KEY
```

Add `--scope project` before `context7` to save the server in the current project's `.autohand` configuration instead of your user configuration.

</details>

## 🔨 Available Tools

Context7 MCP provides the following tools that LLMs can use:

- `resolve-library-id`: Resolves a general library name into a Context7-compatible library ID.
  - `libraryName` (required): The name of the library to search for
  - `query` (required): What you need the docs for, used to rank matches

- `query-docs`: Queries up-to-date documentation and code examples for a Context7-compatible library ID.
  - `libraryId` (required): Exact Context7-compatible library ID (e.g., `/mongodb/docs`, `/vercel/next.js`)
  - `query` (required): The concept to look up, scoped to a single topic
  - `language` (optional): The programming language you write in, used to rank code examples in that language first

- `grep-code`, `glob-code`, `read-code` and `find-symbol` (experimental): Search and read a library's source code at the version its docs describe. They take the parameters of the Grep, Glob and Read tools that coding agents have, with `libraryId` and an optional `version` (a git tag) added. Listed only when the code tools are on: turn them on at [Dashboard > Settings > MCP Tools](https://context7.com/dashboard?tab=settings) for a signed-in client, or turn on every experimental tool with `--experimental` or `CONTEXT7_EXPERIMENTAL=1` (stdio), or `?experimental=1` on the MCP URL (HTTP).
  - `grep-code`: ripgrep over the source. `pattern` (required), `path`, `glob`, `type`, `output_mode` (`content`, `files_with_matches`, `count`), `-A`, `-B`, `-C`, `-i`, `-F`, `-w`, `multiline`, `head_limit`, `offset`
  - `glob-code`: files by name. `pattern` (a glob such as `**/*client*.ts`), `path`, `head_limit`, `offset`; with `path` and no `pattern`, the files and folders of that folder
  - `read-code`: numbered lines of a file. `file_path` (required), `offset` (first line), `limit` (at most 200 lines)
  - `find-symbol`: `operation` `definition`, `references` (resolved with SCIP where indexed) or `outline`, with `symbol`, and `path` for a file

`get-library-docs` was renamed to `query-docs`. Update client tool allowlists to use `query-docs`.

## 🛟 Tips

### Add a Rule

To avoid typing `use context7` in every prompt, you can add a rule to your MCP client that automatically invokes Context7 for code-related questions. See the [recommended setup in the Installation section](#️-installation) for detailed instructions and example rules.

### Use Library Id

If you already know exactly which library you want to use, add its Context7 ID to your prompt. That way, Context7 MCP server can skip the library-matching step and directly continue with retrieving docs.

```txt
Implement basic authentication with Supabase. use library /supabase/supabase for API and docs.
```

The slash syntax tells the MCP tool exactly which library to load docs for.

### HTTPS Proxy

If you are behind an HTTP proxy, Context7 uses the standard `https_proxy` / `HTTPS_PROXY` environment variables.

## 💻 Development

Clone the project and install dependencies:

```bash
bun i
```

Build:

```bash
bun run build
```

Run the server:

```bash
bun run dist/index.js
```

### CLI Arguments

`context7-mcp` accepts the following CLI flags:

- `--transport <stdio|http>` – Transport to use (`stdio` by default). Use `http` for remote HTTP server or `stdio` for local integration.
- `--port <number>` – Port to listen on when using `http` transport (default `3000`).
- `--api-key <key>` – API key for authentication (or set `CONTEXT7_API_KEY` env var). You can get your API key by creating an account at [context7.com/dashboard](https://context7.com/dashboard?tab=settings).
- `--experimental` – List every experimental tool, stdio only (or set `CONTEXT7_EXPERIMENTAL=1`). Without it, a server with an API key lists the experimental tools you turned on at [Dashboard > Settings > MCP Tools](https://context7.com/dashboard?tab=settings), read when it starts. The old names `--research-preview` and `CONTEXT7_RESEARCH_PREVIEW=1` still work. See [Experimental Tools](https://context7.com/docs/howto/experimental-tools).

Example with HTTP transport and port 8080:

```bash
bun run dist/index.js --transport http --port 8080
```

HTTP transport requires a credential on every request by default. Clients send `Authorization: Bearer YOUR_API_KEY`. Set `MCP_AUTH_ENFORCEMENT=observe` to also accept requests without credentials on `/mcp`.

Opaque OAuth access tokens (`oat_…`) are checked against the Context7 API before each request is served (one check per token per minute on each replica; the cache is in memory, and a rejected token stays rejected for ten minutes). An expired or revoked token gets an HTTP 401 with a `WWW-Authenticate` challenge so MCP clients refresh it. Set `MCP_OAUTH_TOKEN_VALIDATION=off` to skip that check and forward the token unchecked.

For a signed-in caller, the server reads the experimental tools turned on in the Context7 dashboard.

The hosted server holds `MCP_CLIENT_IP_ASSERTION_KEY`, the key it shares with the Context7 app. With it, each process keeps every user's choice in memory: it polls the app's internal snapshot endpoint every 15 seconds, which answers `304 Not Modified` unless something changed, and `tools/list` asks clients to cache the list for one minute, so a dashboard change shows within about a minute. API keys, Clerk OAuth JWTs and opaque OAuth tokens (through the user id the auth check returns) are answered from memory, with no call per request; other credentials get no experimental tools from the dashboard. Opaque tokens need an app that returns `X-Context7-User-Id` from `/api/v2/auth/check` and `MCP_OAUTH_TOKEN_VALIDATION` left on; without them those users get none either. While the app is unreachable the last copy stays in use.

Without that key (the stdio server, a self-hosted HTTP server), the server asks the Context7 API and keeps the answer for five minutes per credential.

OAuth JWT access tokens from the authorization server (`OAUTH_AUTH_SERVER_URL`) are verified locally: signature against its JWKS, issuer, a `typ` of `at+jwt`, and expiry with a minute of clock tolerance. Clerk ID tokens and session JWTs share that issuer but are not access tokens, so they are always rejected. The token's `aud` must name this server (`RESOURCE_URL` origin, `/mcp`, or `/mcp/oauth`; override with a comma-separated `MCP_OAUTH_ALLOWED_AUDIENCES`). The query string of an audience on an allowed host is ignored. `MCP_OAUTH_AUDIENCE_ENFORCEMENT` sets what a mismatch does: `observe` (default) admits a token with a missing or foreign audience; `foreign` answers HTTP 401 to a token issued for another server and still admits one with no `aud`; `required` answers 401 to both. Every mismatch is logged with the OAuth client ID, the audience and the outcome, once per token per hour on each replica.

Another example with stdio transport:

```bash
bun run dist/index.js --transport stdio --api-key YOUR_API_KEY
```

### Environment Variables

You can use the `CONTEXT7_API_KEY` environment variable instead of passing the `--api-key` flag. This is useful for:

- Storing API keys securely in `.env` files
- Integration with MCP server setups that use dotenv
- Tools that prefer environment variable configuration

**Note:** The `--api-key` CLI flag takes precedence over the environment variable when both are provided.

**Example with .env file:**

```bash
# .env
CONTEXT7_API_KEY=your_api_key_here
```

**Example MCP configuration using environment variable:**

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp"],
      "env": {
        "CONTEXT7_API_KEY": "YOUR_API_KEY"
      }
    }
  }
}
```

### OpenTelemetry observability

Context7 instruments individual MCP requests and notifications at the SDK transport boundary,
including messages inside a valid batch and MCP v2 `subscriptions/listen` operations handled by the
SDK entry layer. Requests rejected by the SDK's HTTP envelope and protocol-version validation before
dispatch remain visible in normal HTTP/gateway telemetry, but are not reported as MCP operations.
Observed operations follow the
development-status [OpenTelemetry MCP semantic conventions](https://github.com/open-telemetry/semantic-conventions-genai/blob/main/docs/gen-ai/mcp.md)
for server metrics and spans. Trace context is extracted from the `traceparent`, `tracestate`, and
`baggage` fields in MCP `params._meta` as defined by
[SEP-414](https://modelcontextprotocol.io/seps/414-request-meta).

The HTTP transport exposes metrics in Prometheus format on a dedicated listener at
`127.0.0.1:9464/metrics` by default. The production Docker image explicitly binds that listener to
`0.0.0.0` so an internal Prometheus pod scraper or `PodMonitor` can reach it. The stdio transport
does not open a telemetry port. Keeping this listener separate from the public MCP port prevents
the metrics endpoint from being routed through a catch-all gateway rule. On SIGTERM, SIGINT, or
SIGHUP, both transports use a bounded shutdown path that stops serving, closes active MCP
connections and subscriptions, and best-effort flushes externally installed SDK metric and trace
providers before exit. Stdio EOF triggers the same path.

The exporter uses the standard OpenTelemetry Prometheus settings:

- `OTEL_EXPORTER_PROMETHEUS_HOST` changes the bind address (default `127.0.0.1`; the Docker image
  sets `0.0.0.0`).
- `OTEL_EXPORTER_PROMETHEUS_PORT` changes the port (default `9464`).
- `OTEL_METRICS_EXPORTER=none` or `OTEL_SDK_DISABLED=true` disables the embedded exporter.

`OTEL_SDK_DISABLED=true` is the hard-off switch: provider modules are not loaded and MCP
transports and handlers are not wrapped, preserving the baseline request path. In contrast,
`OTEL_METRICS_EXPORTER=none` disables only the embedded Prometheus bootstrap, so a provider
installed by a Node preload can still receive the MCP signals.

Exporter bind or configuration failures are logged but do not prevent the MCP endpoint from
starting. If a Node preload has already registered global OpenTelemetry providers, they take
precedence. The embedded Prometheus listener is not started when a global `MeterProvider` exists,
and MCP spans are exported through the preload's `TracerProvider`. This supports an OpenTelemetry
Node SDK or Kubernetes auto-instrumentation without creating a second provider in the application.
When an external SDK owns the provider, configure its Node runtime instrumentation there as well;
the application does not register a duplicate collector.

It reports bounded-cardinality counters, histograms, and in-flight gauges for MCP methods,
subscriptions, tool outcomes, authentication outcomes, Context7 upstream requests, and Node runtime
saturation.
Prometheus receives these metric families:

- `mcp_server_operation_duration` (its `_count` series is the MCP operation count, and tool-call
  series include the `context7_mcp_tool_outcome` label)
- `mcp_server_session_duration` for real stateful stdio sessions (stateless HTTP request transports
  are intentionally excluded)
- `context7_mcp_operations_active`
- `context7_mcp_subscriptions_active` and `context7_mcp_subscription_duration`
- `context7_mcp_upstream_requests_total` and `context7_mcp_upstream_request_duration`
- `context7_mcp_authentication_attempts_total` and `context7_mcp_authentication_duration`
- `context7_mcp_authentication_events_total` for bounded authentication lifecycle events such as
  credential challenges, metadata discovery, credentialed initialization, and authenticated tool
  use
- `context7_mcp_upstream_requests_active` and `context7_mcp_authentication_active`
- `nodejs_eventloop_*`, `v8js_gc_duration`, `v8js_memory_heap_*`, and
  `v8js_resource_active` from the official OpenTelemetry Node runtime instrumentation

Tool outcomes on the standard MCP operation metric distinguish `success`, `not_found`,
`invalid`, `unavailable`, and `error`; only `error` marks the operation as failed. An
acknowledged `subscriptions/listen` operation is timed through its acknowledgement; the
separate subscription metrics track the active stream and its bounded terminal outcome.
Upstream outcomes distinguish
HTTP, response-decoding, network, timeout, and cancellation failures and include both the bounded
status-code class and the exact numeric HTTP status. Authentication reports accepted, missing,
invalid, and unexpected-error outcomes. Authentication event series use only the bounded route,
enforcement mode, event, method, and outcome dimensions. The OAuth authorization-server metadata
proxy caps its upstream fetch at 10 seconds and returns `502` if that dependency times out.

The labels intentionally exclude API keys, client IPs, queries, library IDs, session IDs, and raw
error text. Expose port `9464` only to your Prometheus scraper or `ServiceMonitor`, not through the
public MCP ingress. For continuity with existing MCP series, the route label uses `anonymous` for
the standard `/mcp` path and `oauth` for the `/mcp/oauth` compatibility alias; the `anonymous` value
identifies the route and does not imply that the request bypassed authentication. The enforcement
label reports the mode applied to each request: `/mcp/oauth` and Claude Code plugin requests report
`required` while the server runs in `observe` mode, because those clients always receive the
challenge.

#### Signal ownership with an Envoy gateway

Do not treat `mcp_server_operation_duration_count` as another HTTP request counter. An Envoy
Gateway observes HTTP envelopes, while this metric observes JSON-RPC requests and notifications
after SDK dispatch. A valid batch is one HTTP request but several MCP operations, and HTTP requests
rejected before MCP dispatch never increment the MCP metric.

Context7 deliberately does **not** register generic inbound HTTP server metrics. Keep the following
signals in the existing Envoy scrape instead of collecting them again from the application:

- downstream HTTP request/response totals, status classes, duration, active requests, connections,
  resets, and gateway timeouts (`envoy_http_*_downstream_*`)
- Envoy-to-MCP backend request totals, status codes, duration, active/pending requests, connection
  failures, retries, resets, timeouts, and circuit-breaker overflows (`envoy_cluster_upstream_*`)
- Envoy process health and resource metrics

The application exporter owns only signals the ingress gateway cannot provide: MCP method and
protocol semantics (including batches, notifications, and active MCP v2 subscriptions), tool and
authentication outcomes, MCP-to-Context7 API calls, and Node event-loop/V8 health. In the
Kubernetes deployment Envoy is a
Gateway API proxy rather than a sidecar in the MCP pod, so `context7_mcp_upstream_*` describes the
MCP server's outbound Context7 API dependency, not Envoy's inbound MCP backend cluster. Pod and
container CPU, memory, network, and restart metrics should continue to come from the Kubernetes
monitoring stack.

See the [Envoy HTTP connection manager statistics](https://www.envoyproxy.io/docs/envoy/latest/configuration/http/http_conn_man/stats)
and [upstream cluster statistics](https://www.envoyproxy.io/docs/envoy/latest/configuration/upstream/cluster_manager/cluster_stats.html)
for the proxy-owned metric families.

For a replicated Kubernetes deployment, discover and scrape every MCP pod directly. Do not use one
static, load-balanced Service target: successive scrapes can reach different replicas and produce
incomplete per-process counters and runtime series. For an annotation-based `kubernetes-pods`
scrape job, add the following fields to the MCP workload's pod template:

```yaml
spec:
  template:
    metadata:
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "9464"
        prometheus.io/path: /metrics
    spec:
      containers:
        - name: mcp
          ports:
            - name: metrics
              containerPort: 9464
              protocol: TCP
```

Prometheus will then scrape `http://<mcp-pod-ip>:9464/metrics` for each replica. Declaring
`EXPOSE 9464` in the image does not add the Kubernetes `containerPort` metadata. The scrape interval
is controlled by Prometheus; the exporter does not impose one. If the monitoring stack uses the
Prometheus Operator instead, configure the equivalent per-pod endpoint with a `PodMonitor`.

<details>
<summary><b>Local Configuration Example</b></summary>

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["tsx", "/path/to/folder/context7/src/index.ts", "--api-key", "YOUR_API_KEY"]
    }
  }
}
```

</details>

### OAuth Authentication

Context7 MCP server supports OAuth 2.0 authentication for MCP clients that implement the [MCP OAuth specification](https://modelcontextprotocol.io/specification/latest/basic/authorization).

To use OAuth, change the endpoint from `/mcp` to `/mcp/oauth` in your client configuration:

```diff
- "url": "https://mcp.context7.com/mcp"
+ "url": "https://mcp.context7.com/mcp/oauth"
```

> **Note:** OAuth is not supported with stdio transport. For local MCP connections, use API key authentication instead.

<details>
<summary><b>Testing with MCP Inspector</b></summary>

```bash
npx -y @modelcontextprotocol/inspector npx @upstash/context7-mcp
```

</details>

## 🚨 Troubleshooting

<details>
<summary><b>Module Not Found Errors</b></summary>

If you encounter `ERR_MODULE_NOT_FOUND`, try using `bunx` instead of `npx`:

```json
{
  "mcpServers": {
    "context7": {
      "command": "bunx",
      "args": ["-y", "@upstash/context7-mcp"]
    }
  }
}
```

This often resolves module resolution issues in environments where `npx` doesn't properly install or resolve packages.

</details>

<details>
<summary><b>ESM Resolution Issues</b></summary>

For errors like `Error: Cannot find module 'uriTemplate.js'`, try the `--experimental-vm-modules` flag:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "--node-options=--experimental-vm-modules", "@upstash/context7-mcp"]
    }
  }
}
```

</details>

<details>
<summary><b>TLS/Certificate Issues</b></summary>

Use the `--experimental-fetch` flag to bypass TLS-related problems:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "--node-options=--experimental-fetch", "@upstash/context7-mcp"]
    }
  }
}
```

</details>

<details>
<summary><b>General MCP Client Errors</b></summary>

1. Try adding `@latest` to the package name
2. Use `bunx` as an alternative to `npx`
3. Consider using `deno` as another alternative
4. Ensure you're using Node.js v20 or higher for native fetch support

</details>

## ⚠️ Disclaimer

1- Context7 projects are community-contributed and while we strive to maintain high quality, we cannot guarantee the accuracy, completeness, or security of all library documentation. Projects listed in Context7 are developed and maintained by their respective owners, not by Context7. If you encounter any suspicious, inappropriate, or potentially harmful content, please use the "Report" button on the project page to notify us immediately. We take all reports seriously and will review flagged content promptly to maintain the integrity and safety of our platform. By using Context7, you acknowledge that you do so at your own discretion and risk.

2- This repository hosts the MCP server’s source code. The supporting components — API backend, parsing engine, and crawling engine — are private and not part of this release.

## 🤝 Connect with Us

Stay updated and join our community:

- 📢 Follow us on [X](https://x.com/context7ai) for the latest news and updates
- 🌐 Visit our [Website](https://context7.com)
- 💬 Join our [Discord Community](https://upstash.com/discord)

## 📺 Context7 In Media

- [Better Stack: "Free Tool Makes Cursor 10x Smarter"](https://youtu.be/52FC3qObp9E)
- [Cole Medin: "This is Hands Down the BEST MCP Server for AI Coding Assistants"](https://www.youtube.com/watch?v=G7gK8H6u7Rs)
- [Income Stream Surfers: "Context7 + SequentialThinking MCPs: Is This AGI?"](https://www.youtube.com/watch?v=-ggvzyLpK6o)
- [Julian Goldie SEO: "Context7: New MCP AI Agent Update"](https://www.youtube.com/watch?v=CTZm6fBYisc)
- [JeredBlu: "Context 7 MCP: Get Documentation Instantly + VS Code Setup"](https://www.youtube.com/watch?v=-ls0D-rtET4)
- [Income Stream Surfers: "Context7: The New MCP Server That Will CHANGE AI Coding"](https://www.youtube.com/watch?v=PS-2Azb-C3M)
- [AICodeKing: "Context7 + Cline & RooCode: This MCP Server Makes CLINE 100X MORE EFFECTIVE!"](https://www.youtube.com/watch?v=qZfENAPMnyo)
- [Sean Kochel: "5 MCP Servers For Vibe Coding Glory (Just Plug-In & Go)"](https://www.youtube.com/watch?v=LqTQi8qexJM)

## Vercel Marketplace OIDC

Vercel Marketplace resources can call the remote MCP server without a
long-lived Context7 API key. Obtain a fresh per-resource access token from
Vercel's Marketplace integration runtime and send it as the bearer credential:

```ts
import { getIntegrationToken } from "@vercel/integrations";

const authorization = `Bearer ${await getIntegrationToken("context7")}`;
```

The `getIntegrationToken` signature is based on Vercel's current provider
specification and may change before Marketplace OIDC is generally available.

Use `authorization` as the `Authorization` header when creating the MCP HTTP
transport. Create the transport inside the request that uses it so a short-lived
token is not retained across function invocations. Its `resource` claim must
match the Context7 resource created during Marketplace provisioning.

The hosted MCP service must be configured with the exact issuer and audience
assigned by Vercel when the Context7 Marketplace product is created:

```sh
VERCEL_MARKETPLACE_OIDC_ISSUER=https://integrations.vercel.com/oac_...
VERCEL_MARKETPLACE_OIDC_AUDIENCE=https://integrations.vercel.com/context7/icfg_...
```

## 📄 License

MIT
